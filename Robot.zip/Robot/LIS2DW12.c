#include <LIS2DW12.h>

const uint8_t ctrl1[] = {0x20, 0x40}; 		// low-power mode, 12-bit, 50 Hz
const uint8_t ctrl3[] = {0x22, 0x38};		// open-drain INT, active low

acc_sensor_data_t ACC_data;
I2C_TransferSeq_TypeDef seqR, seqW;
I2C_TransferReturn_TypeDef ret;

void LIS2DW12_setup()
{
	seqR.addr = LIS2DW12_SLAVE_ADDRESS;		// setup read/write structures
	seqR.flags = I2C_FLAG_WRITE_READ;
	seqR.buf[0].len = 1;					// write 1 byte (reg address)
    seqR.buf[1].data = (uint8_t*) &ACC_data;// read data destination

	seqW.addr = LIS2DW12_SLAVE_ADDRESS;
	seqW.flags = I2C_FLAG_WRITE;
	seqW.buf[0].len = 2;

	seqW.buf[0].data = (uint8_t*)ctrl1;
	ret = I2C_TransferInit(I2C0, &seqW);
	while (ret == i2cTransferInProgress)
		ret = I2C_Transfer(I2C0);

	seqW.buf[0].data = (uint8_t*)ctrl3;
	ret = I2C_TransferInit(I2C0, &seqW);
	while (ret == i2cTransferInProgress)
		ret = I2C_Transfer(I2C0);

	LIS2DW12_test();
	LIS2DW12_getInt();
}

void LIS2DW12_getInt()
{
	uint8_t all_int[] = {0x3B};				// all interrupts register
	seqR.buf[0].data = all_int;
    seqR.buf[1].len = 1;					// read 1 byte
	ret = I2C_TransferInit(I2C0, &seqR);
	while (ret == i2cTransferInProgress)
		ret = I2C_Transfer(I2C0);
}

void LIS2DW12_getData()
{
	uint8_t status[] = {0x27};				// status register
	seqR.buf[0].data = status;
    seqR.buf[1].len = 7;					// read status and ACC data
	ret = I2C_TransferInit(I2C0, &seqR);
	while (ret == i2cTransferInProgress)
		ret = I2C_Transfer(I2C0);
}

void LIS2DW12_test()
{
	uint8_t test[] = {0x0F};				// who_am_i register
	seqR.buf[0].data = test;
    seqR.buf[1].len = 1;					// read 1 byte
	ret = I2C_TransferInit(I2C0, &seqR);
	while (ret == i2cTransferInProgress)
		ret = I2C_Transfer(I2C0);			// should return 0x44
}
