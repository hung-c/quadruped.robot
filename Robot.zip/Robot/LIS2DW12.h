#ifndef LIS2DW12_H_
#define LIS2DW12_H_

#include "em_i2c.h"
#define LIS2DW12_SLAVE_ADDRESS       0x32   // sensor slave address

typedef struct {
  uint8_t   status;
  int16_t  x;
  int16_t  y;
  int16_t  z;
} __attribute__((__packed__)) acc_sensor_data_t;
extern acc_sensor_data_t ACC_data;

void LIS2DW12_setup(void);					// function prototypes
void LIS2DW12_getInt(void);
void LIS2DW12_getData(void);
void LIS2DW12_test(void);

#endif
