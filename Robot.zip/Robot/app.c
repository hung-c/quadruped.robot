/* Bluetooth stack headers */
#include <LIS2DW12.h>
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"

#include "app.h"
#include "em_i2c.h"
#include "em_cmu.h"
#include "em_rtcc.h"
#include "em_letimer.h"
#include "em_timer.h"

#define PWM_FREQ 50												// PWM frequency

// local function prototypes
void initHardware(void);
void setPWMPulseWidth(TIMER_TypeDef *timer, unsigned int ch, float duration);

// global variables
uint16_t timerTOP;

/* Main application */
void appMain(gecko_configuration_t *pconfig)
{
#if DISABLE_SLEEP > 0											// disable deep sleep
	pconfig->sleep.flags = 0;									// to generate PWM continuously
#endif

	initHardware();
	setPWMPulseWidth(TIMER0, 0, 1.0);							// set initial PWM pulse width on all channels
	setPWMPulseWidth(TIMER0, 1, 1.0);
	setPWMPulseWidth(TIMER1, 0, 1.0);
	setPWMPulseWidth(TIMER1, 1, 1.0);
	setPWMPulseWidth(TIMER1, 2, 1.0);
	setPWMPulseWidth(TIMER1, 3, 1.0);
	setPWMPulseWidth(WTIMER0, 0, 1.0);
	setPWMPulseWidth(WTIMER0, 1, 1.0);

	while(1)
	{
		__WFI();
		GPIO_PinOutToggle(BSP_LED0_PORT, BSP_LED0_PIN);			// toggle LED
		LIS2DW12_getData();										// get ACC data
		__NOP();												// put breakpoint here to examine the ACC data
	}
}

void initHardware(void)
{
  	// Initialize debug prints. Note: debug prints are off by default. See DEBUG_LEVEL in app.h
	initLog();

	// enable sensor on board and init I2C0 module
	I2C_Init_TypeDef i2cInit = I2C_INIT_DEFAULT;
	i2cInit.freq = 400000;
	CMU_ClockEnable(cmuClock_HFPER, true);
	CMU_ClockEnable(cmuClock_I2C0, true);
	CMU_ClockEnable(cmuClock_RTCC, true);
	CMU_ClockEnable(cmuClock_GPIO, true);
	GPIO_PinModeSet(gpioPortC, 11, gpioModeInputPull, 1);		// sensor INT, pull-up
	GPIO_PinModeSet(gpioPortC, 9, gpioModeWiredAnd, 1);			// sensor SDA
	GPIO_PinModeSet(gpioPortC, 10, gpioModeWiredAnd, 1);		// sensor SCL
	I2C0->ROUTELOC0 = I2C_ROUTELOC0_SDALOC_LOC14 |
  			  	  	  I2C_ROUTELOC0_SCLLOC_LOC14;
	I2C0->ROUTEPEN = 3;
	I2C_Init(I2C0, &i2cInit);
	LIS2DW12_setup();											// init accelerometer

	// switch pins configuration
	GPIO_PinModeSet(gpioPortD, 15, gpioModeInputPull, 1);		// leg switch pull-up
	GPIO_PinModeSet(gpioPortA, 0, gpioModeInputPull, 1);		// leg switch pull-up
	GPIO_PinModeSet(gpioPortF, 5, gpioModeInputPull, 1);		// leg switch pull-up
	GPIO_PinModeSet(gpioPortF, 6, gpioModeInputPull, 1);		// leg switch pull-up

	// init LED
	GPIO_PinModeSet(BSP_LED0_PORT, BSP_LED0_PIN, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortD, 13, gpioModePushPull, 0);

	// init PWM pins
	GPIO_PinModeSet(gpioPortA, 1, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortA, 2, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortA, 4, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortF, 2, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortF, 3, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortF, 4, gpioModePushPull, 0);
	GPIO_PinModeSet(gpioPortF, 5, gpioModePushPull, 0);

	// LETIMER setup
	LETIMER_Init_TypeDef letimerInit = LETIMER_INIT_DEFAULT;
	CMU_ClockEnable(cmuClock_LETIMER0, true);
	letimerInit.comp0Top  = true;
	letimerInit.topValue = 32767;
	LETIMER_IntEnable(LETIMER0, LETIMER_IEN_UF);			// enable interrupt
	LETIMER_Init(LETIMER0, &letimerInit);
	NVIC_ClearPendingIRQ(LETIMER0_IRQn);
	NVIC_EnableIRQ(LETIMER0_IRQn);

	// PWM setup
	CMU_ClockEnable(cmuClock_TIMER0, true);
	CMU_ClockEnable(cmuClock_TIMER1, true);
	CMU_ClockEnable(cmuClock_WTIMER0, true);
	// Configure Compare/Capture for output compare
	// Use PWM mode, which sets output on overflow and clears on compare events
	TIMER_InitCC_TypeDef timerCCInit = TIMER_INITCC_DEFAULT;
	timerCCInit.mode = timerCCModePWM;
	TIMER_InitCC(TIMER0, 0, &timerCCInit);
	TIMER_InitCC(TIMER0, 1, &timerCCInit);
	TIMER_InitCC(TIMER1, 0, &timerCCInit);
	TIMER_InitCC(TIMER1, 1, &timerCCInit);
	TIMER_InitCC(TIMER1, 2, &timerCCInit);
	TIMER_InitCC(TIMER1, 3, &timerCCInit);
	TIMER_InitCC(WTIMER0, 0, &timerCCInit);
	TIMER_InitCC(WTIMER0, 1, &timerCCInit);
	TIMER0->ROUTELOC0 |=  TIMER_ROUTELOC0_CC0LOC_LOC1 +
			              TIMER_ROUTELOC0_CC1LOC_LOC1;
	TIMER0->ROUTEPEN  |=  TIMER_ROUTEPEN_CC0PEN +
						  TIMER_ROUTEPEN_CC1PEN;
	TIMER1->ROUTELOC0 |=  TIMER_ROUTELOC0_CC0LOC_LOC29 +
				          TIMER_ROUTELOC0_CC1LOC_LOC27 +
						  TIMER_ROUTELOC0_CC2LOC_LOC25 +
						  TIMER_ROUTELOC0_CC3LOC_LOC23;
	TIMER1->ROUTEPEN  |=  TIMER_ROUTEPEN_CC0PEN +
						  TIMER_ROUTEPEN_CC1PEN +
						  TIMER_ROUTEPEN_CC2PEN +
						  TIMER_ROUTEPEN_CC3PEN;
	WTIMER0->ROUTELOC0 |= WTIMER_ROUTELOC0_CC0LOC_LOC3 +
				          WTIMER_ROUTELOC0_CC1LOC_LOC2;
	WTIMER0->ROUTEPEN  |= WTIMER_ROUTEPEN_CC0PEN +
						  WTIMER_ROUTEPEN_CC1PEN;
	timerTOP = (CMU_ClockFreqGet(cmuClock_TIMER0) >> 4) / PWM_FREQ;
	TIMER_TopSet(TIMER0, timerTOP); // set PWM freq
	TIMER_TopSet(TIMER1, timerTOP);
	TIMER_TopSet(WTIMER0, timerTOP);
	TIMER_Init_TypeDef timerInit = TIMER_INIT_DEFAULT;
	timerInit.prescale = timerPrescale16;
	TIMER_Init(TIMER0, &timerInit);
	TIMER_Init(TIMER1, &timerInit);
	TIMER_Init(WTIMER0, &timerInit);


// 	gecko_init(pconfig);									// Initialize Bluetooth stack
}

void setPWMPulseWidth(TIMER_TypeDef *timer, unsigned int ch, float width) // pulse width in ms
{
	timer->CC[ch].CCV = (width*timerTOP*PWM_FREQ) / 1000;
}

void LETIMER0_IRQHandler(void)
{
	LETIMER_IntClear(LETIMER0, LETIMER_IF_UF);
}
